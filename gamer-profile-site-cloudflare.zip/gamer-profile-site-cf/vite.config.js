import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Cloudflare Pages serves the site from the domain root
// (both on *.pages.dev and on a custom domain), so base stays "/".
export default defineConfig({
  plugins: [react()],
  base: "/",
});
