import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Pencil, Plus, X, Trash2, MapPin, Check, Loader2, Upload, Download, FileUp,
  Twitch, Youtube, Twitter, Instagram, Music2, MessageSquare,
  Gamepad2, Cpu, Image as ImageIcon, Link as LinkIcon,
  ArrowUp, ArrowDown, LayoutGrid, Sliders, Blocks, Share2,
} from "lucide-react";

/* ---------------------------------------------------------
   FONTS
--------------------------------------------------------- */
function useFonts() {
  useEffect(() => {
    const id = "knt-fonts";
    if (document.getElementById(id)) return;
    const link = document.createElement("link");
    link.id = id;
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap";
    document.head.appendChild(link);
  }, []);
}

/* ---------------------------------------------------------
   IMAGE COMPRESSION (upload -> resized base64)
--------------------------------------------------------- */
function fileToCompressedDataURL(file, maxDim = 1100, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read failed"));
    reader.onload = () => {
      const img = new window.Image();
      img.onerror = () => reject(new Error("decode failed"));
      img.onload = () => {
        let { width, height } = img;
        if (width > height && width > maxDim) {
          height = Math.round((height * maxDim) / width);
          width = maxDim;
        } else if (height >= width && height > maxDim) {
          width = Math.round((width * maxDim) / height);
          height = maxDim;
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/* ---------------------------------------------------------
   PLATFORM ICONS FOR LINK SECTIONS
--------------------------------------------------------- */
const PLATFORMS = [
  { id: "twitch", label: "Twitch", icon: Twitch },
  { id: "youtube", label: "YouTube", icon: Youtube },
  { id: "twitter", label: "X / Twitter", icon: Twitter },
  { id: "instagram", label: "Instagram", icon: Instagram },
  { id: "tiktok", label: "TikTok", icon: Music2 },
  { id: "discord", label: "Discord", icon: MessageSquare },
  { id: "website", label: "Site", icon: LinkIcon },
];
const platformIcon = (id) => (PLATFORMS.find((p) => p.id === id) || PLATFORMS[6]).icon;

const SECTION_TYPES = [
  { type: "cards", label: "Grade de itens", icon: LayoutGrid, hint: "setup, jogos, o que quiser" },
  { type: "settings", label: "Jogos & configs", icon: Sliders, hint: "sensibilidade, DPI, crosshair" },
  { type: "links", label: "Links", icon: Share2, hint: "redes sociais e sites" },
  { type: "blocks", label: "Blocos", icon: Blocks, hint: "foto, título e texto livre" },
];

/* ---------------------------------------------------------
   DEFAULT DATA
--------------------------------------------------------- */
const uid = () => Math.random().toString(36).slice(2, 9);

const defaultData = {
  profile: {
    banner: "",
    bannerColor: "linear-gradient(135deg,#1c1f1a 0%,#14140f 60%,#0c0c0a 100%)",
    avatar: "",
    name: "Mika Lindqvist",
    handle: "mikaplays",
    bio: "FPS main. Monto um setup novo todo inverno. Streaming o grind, não os highlights.",
    location: "Gotemburgo, SE",
  },
  sections: [
    {
      id: "sec-setup", type: "cards", title: "Setup",
      items: [
        { id: "s1", image: "", tag: "Periférico", title: "Teclado", detail: "60% hotswap, switches marrons" },
        { id: "s2", image: "", tag: "Periférico", title: "Mouse", detail: "49g wireless, sensor 26k" },
        { id: "s3", image: "", tag: "PC", title: "GPU", detail: "RTX 4080 Super" },
        { id: "s4", image: "", tag: "Monitor", title: "Display", detail: "27\" 1440p · 240Hz" },
      ],
    },
    {
      id: "sec-games", type: "cards", title: "Jogos favoritos",
      items: [
        { id: "g1", image: "", tag: "Duelist", title: "Valorant", detail: "Main · Immortal" },
        { id: "g2", image: "", tag: "AWPer", title: "Counter-Strike 2", detail: "Faceit nível 9" },
        { id: "g3", image: "", tag: "Wraith", title: "Apex Legends", detail: "Diamante" },
      ],
    },
    {
      id: "sec-settings", type: "settings", title: "Configurações em jogo",
      games: [
        { id: "sg1", name: "Valorant", image: "" },
        { id: "sg2", name: "Counter-Strike 2", image: "" },
      ],
      settingsByGame: {
        sg1: [
          { id: "v1", label: "Sensibilidade", value: "0.32" },
          { id: "v2", label: "DPI", value: "800" },
          { id: "v3", label: "Crosshair", value: "0;s;1;P;c;5;h;0;f;0;0l;3" },
        ],
        sg2: [
          { id: "c1", label: "Sensibilidade", value: "1.8" },
          { id: "c2", label: "DPI", value: "800" },
          { id: "c3", label: "Resolução", value: "1280x960 esticada" },
        ],
      },
      activeGameId: "sg1",
    },
    {
      id: "sec-links", type: "links", title: "Redes",
      items: [
        { id: "l1", platform: "twitch", label: "twitch.tv/mikaplays", url: "https://twitch.tv/mikaplays" },
        { id: "l2", platform: "twitter", label: "x.com/mikaplays", url: "https://x.com/mikaplays" },
      ],
    },
    {
      id: "sec-custom", type: "blocks", title: "Bastidores",
      items: [
        { id: "b1", image: "", title: "Tour pela mesa", content: "Walkthrough completo do setup, cabos escondidos e iluminação." },
      ],
    },
  ],
};

/* ---------------------------------------------------------
   PERSISTENCE — localStorage acts as the on-device database.
   Everything is saved in the visitor's own browser. There is
   no shared backend, so data does not sync across devices.
   Swap this hook for a real API/DB call if you need that.
--------------------------------------------------------- */
const STORAGE_KEY = "gamer-profile-page-v2";

function usePersistedState() {
  const [data, setData] = useState(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) return { ...defaultData, ...JSON.parse(raw) };
    } catch (e) {
      /* first run, or storage blocked — fall back to defaults */
    }
    return defaultData;
  });
  const [status, setStatus] = useState("ready"); // ready | saving | saved | error
  const first = useRef(true);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    setStatus("saving");
    const t = setTimeout(() => {
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        setStatus("saved");
      } catch (e) {
        setStatus("error");
      }
    }, 400);
    return () => clearTimeout(t);
  }, [data]);

  return [data, setData, status];
}

/* ---------------------------------------------------------
   SMALL UI PRIMITIVES
--------------------------------------------------------- */
function EditableText({ value, onChange, placeholder, tag = "span", className = "", editMode }) {
  if (!editMode) {
    const Tag = tag;
    return <Tag className={className}>{value || <span className="knt-placeholder">{placeholder}</span>}</Tag>;
  }
  return (
    <input
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      className={`knt-inline-input ${className}`}
    />
  );
}

function EditableArea({ value, onChange, placeholder, className = "", editMode }) {
  if (!editMode) {
    return <p className={className}>{value || <span className="knt-placeholder">{placeholder}</span>}</p>;
  }
  return (
    <textarea
      value={value}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      rows={3}
      className={`knt-inline-textarea ${className}`}
    />
  );
}

function ImageBox({ value, onChange, editMode, className = "", Icon = ImageIcon, round = false }) {
  const inputRef = useRef(null);
  const [showUrl, setShowUrl] = useState(false);
  const [busy, setBusy] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    setBusy(true);
    try {
      const dataUrl = await fileToCompressedDataURL(file, round ? 500 : 1100, 0.72);
      onChange(dataUrl);
    } catch (err) {
      /* ignore bad file */
    }
    setBusy(false);
  };

  return (
    <div
      className={`knt-imgbox ${round ? "knt-imgbox--round" : ""} ${className}`}
      style={value ? { backgroundImage: `url(${value})` } : {}}
    >
      {!value && <Icon size={round ? 26 : 22} strokeWidth={1.4} className="knt-imgbox-icon" />}
      {editMode && (
        <div className="knt-imgbox-overlay">
          <div className="knt-imgbox-controls">
            <button type="button" className="knt-imgbox-btn" onClick={() => inputRef.current?.click()} disabled={busy}>
              {busy ? <Loader2 size={12} className="knt-spin" /> : <Upload size={12} strokeWidth={2} />}
              {busy ? "…" : "Upload"}
            </button>
            <button type="button" className="knt-imgbox-btn" onClick={() => setShowUrl((s) => !s)}>
              <LinkIcon size={12} strokeWidth={2} />
            </button>
            {value && (
              <button type="button" className="knt-imgbox-btn knt-imgbox-btn--danger" onClick={() => onChange("")}>
                <X size={12} strokeWidth={2} />
              </button>
            )}
          </div>
          {showUrl && (
            <input
              autoFocus
              className="knt-mini-input knt-imgbox-urlinput"
              placeholder="Cole a URL da imagem"
              defaultValue={value && value.startsWith("http") ? value : ""}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  onChange(e.currentTarget.value);
                  setShowUrl(false);
                }
              }}
              onBlur={(e) => {
                if (e.target.value) onChange(e.target.value);
                setShowUrl(false);
              }}
            />
          )}
        </div>
      )}
      <input ref={inputRef} type="file" accept="image/*" onChange={handleFile} style={{ display: "none" }} />
    </div>
  );
}

function SectionShell({ section, editMode, onTitleChange, onMoveUp, onMoveDown, onRemove, canUp, canDown, children }) {
  return (
    <section className="knt-section">
      <div className="knt-section-head">
        <EditableText
          tag="h2"
          className="knt-section-title"
          value={section.title}
          placeholder="Título da seção"
          editMode={editMode}
          onChange={onTitleChange}
        />
        {editMode && (
          <div className="knt-section-controls">
            <button className="knt-iconbtn" disabled={!canUp} onClick={onMoveUp} title="Mover para cima">
              <ArrowUp size={14} strokeWidth={2} />
            </button>
            <button className="knt-iconbtn" disabled={!canDown} onClick={onMoveDown} title="Mover para baixo">
              <ArrowDown size={14} strokeWidth={2} />
            </button>
            <button className="knt-iconbtn knt-iconbtn--danger" onClick={onRemove} title="Remover seção">
              <Trash2 size={14} strokeWidth={2} />
            </button>
          </div>
        )}
      </div>
      {children}
    </section>
  );
}

/* ---------------------------------------------------------
   MAIN COMPONENT
--------------------------------------------------------- */
export default function GamerProfile() {
  useFonts();
  const [data, setData, status] = usePersistedState();
  const [editMode, setEditMode] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);
  const backupInputRef = useRef(null);

  const exportBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `perfil-${data.profile.handle || "backup"}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const importBackup = (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        setData({ ...defaultData, ...parsed });
      } catch (err) {
        alert("Arquivo inválido. Selecione um backup .json exportado deste site.");
      }
    };
    reader.readAsText(file);
  };

  const patchProfile = useCallback((key, val) => {
    setData((d) => ({ ...d, profile: { ...d.profile, [key]: val } }));
  }, [setData]);

  const patchSection = useCallback((id, patch) => {
    setData((d) => ({ ...d, sections: d.sections.map((s) => (s.id === id ? { ...s, ...patch } : s)) }));
  }, [setData]);

  const patchItems = useCallback((id, updater) => {
    setData((d) => ({ ...d, sections: d.sections.map((s) => (s.id === id ? { ...s, items: updater(s.items) } : s)) }));
  }, [setData]);

  const moveSection = (id, dir) => {
    setData((d) => {
      const idx = d.sections.findIndex((s) => s.id === id);
      const swap = idx + dir;
      if (swap < 0 || swap >= d.sections.length) return d;
      const next = [...d.sections];
      [next[idx], next[swap]] = [next[swap], next[idx]];
      return { ...d, sections: next };
    });
  };

  const removeSection = (id) => setData((d) => ({ ...d, sections: d.sections.filter((s) => s.id !== id) }));

  const addSection = (type) => {
    const base = { id: uid(), title: "Nova seção" };
    let section;
    if (type === "cards") section = { ...base, type, title: "Nova grade", items: [] };
    if (type === "blocks") section = { ...base, type, title: "Novos blocos", items: [] };
    if (type === "links") section = { ...base, type, title: "Links", items: [] };
    if (type === "settings") section = { ...base, type, title: "Configurações", games: [], settingsByGame: {}, activeGameId: null };
    setData((d) => ({ ...d, sections: [...d.sections, section] }));
    setPickerOpen(false);
  };

  /* ---- settings-section helpers ---- */
  const addGameToSettings = (sectionId) =>
    setData((d) => ({
      ...d,
      sections: d.sections.map((s) => {
        if (s.id !== sectionId) return s;
        const newGame = { id: uid(), name: "Novo jogo", image: "" };
        return {
          ...s,
          games: [...s.games, newGame],
          activeGameId: s.activeGameId || newGame.id,
          settingsByGame: { ...s.settingsByGame, [newGame.id]: [] },
        };
      }),
    }));

  const removeGameFromSettings = (sectionId, gameId) =>
    setData((d) => ({
      ...d,
      sections: d.sections.map((s) => {
        if (s.id !== sectionId) return s;
        const games = s.games.filter((g) => g.id !== gameId);
        const settingsByGame = { ...s.settingsByGame };
        delete settingsByGame[gameId];
        const activeGameId = s.activeGameId === gameId ? (games[0] ? games[0].id : null) : s.activeGameId;
        return { ...s, games, settingsByGame, activeGameId };
      }),
    }));

  const updateGameInSettings = (sectionId, gameId, key, val) =>
    setData((d) => ({
      ...d,
      sections: d.sections.map((s) =>
        s.id !== sectionId ? s : { ...s, games: s.games.map((g) => (g.id === gameId ? { ...g, [key]: val } : g)) }
      ),
    }));

  const addSettingRow = (sectionId, gameId) =>
    setData((d) => ({
      ...d,
      sections: d.sections.map((s) =>
        s.id !== sectionId
          ? s
          : {
              ...s,
              settingsByGame: {
                ...s.settingsByGame,
                [gameId]: [...(s.settingsByGame[gameId] || []), { id: uid(), label: "Configuração", value: "" }],
              },
            }
      ),
    }));

  const updateSettingRow = (sectionId, gameId, rowId, key, val) =>
    setData((d) => ({
      ...d,
      sections: d.sections.map((s) =>
        s.id !== sectionId
          ? s
          : {
              ...s,
              settingsByGame: {
                ...s.settingsByGame,
                [gameId]: (s.settingsByGame[gameId] || []).map((r) => (r.id === rowId ? { ...r, [key]: val } : r)),
              },
            }
      ),
    }));

  const removeSettingRow = (sectionId, gameId, rowId) =>
    setData((d) => ({
      ...d,
      sections: d.sections.map((s) =>
        s.id !== sectionId
          ? s
          : { ...s, settingsByGame: { ...s.settingsByGame, [gameId]: (s.settingsByGame[gameId] || []).filter((r) => r.id !== rowId) } }
      ),
    }));

  return (
    <div className="knt-root">
      <style>{CSS}</style>

      {/* ---------------- BANNER ---------------- */}
      <div className="knt-banner" style={{ background: data.profile.bannerColor }}>
        <ImageBox
          value={data.profile.banner}
          onChange={(v) => patchProfile("banner", v)}
          editMode={editMode}
          className="knt-banner-img"
          Icon={ImageIcon}
        />
      </div>

      <div className="knt-shell">
        {/* ---------------- HEADER ---------------- */}
        <header className="knt-header">
          <ImageBox
            value={data.profile.avatar}
            onChange={(v) => patchProfile("avatar", v)}
            editMode={editMode}
            className="knt-avatar"
            round
            Icon={Gamepad2}
          />

          <div className="knt-id">
            <div className="knt-id-row">
              <EditableText
                tag="h1"
                className="knt-name"
                value={data.profile.name}
                placeholder="Nome de exibição"
                editMode={editMode}
                onChange={(v) => patchProfile("name", v)}
              />
              <button
                className={`knt-editbtn ${editMode ? "knt-editbtn--active" : ""}`}
                onClick={() => setEditMode((e) => !e)}
              >
                {editMode ? <Check size={14} strokeWidth={2} /> : <Pencil size={13} strokeWidth={2} />}
                {editMode ? "Concluído" : "Editar página"}
              </button>
            </div>

            <div className="knt-handle-row">
              <span className="knt-handle-at">@</span>
              <EditableText
                className="knt-handle"
                value={data.profile.handle}
                placeholder="usuario"
                editMode={editMode}
                onChange={(v) => patchProfile("handle", v)}
              />
              <span className="knt-dot">·</span>
              <MapPin size={13} strokeWidth={1.8} className="knt-loc-icon" />
              <EditableText
                className="knt-loc"
                value={data.profile.location}
                placeholder="Localização"
                editMode={editMode}
                onChange={(v) => patchProfile("location", v)}
              />
            </div>

            <EditableArea
              className="knt-bio"
              value={data.profile.bio}
              placeholder="Escreva uma bio curta…"
              editMode={editMode}
              onChange={(v) => patchProfile("bio", v)}
            />
          </div>
        </header>

        <div className="knt-save-status">
          {status === "saving" && <><Loader2 size={12} className="knt-spin" /> Salvando</>}
          {status === "saved" && <><Check size={12} /> Salvo</>}
          {status === "error" && <>Não foi possível salvar</>}
          <span className="knt-backup-row">
            <button className="knt-backup-btn" onClick={exportBackup}>
              <Download size={12} strokeWidth={2} /> Baixar backup
            </button>
            <button className="knt-backup-btn" onClick={() => backupInputRef.current?.click()}>
              <FileUp size={12} strokeWidth={2} /> Restaurar backup
            </button>
            <input ref={backupInputRef} type="file" accept="application/json" style={{ display: "none" }} onChange={importBackup} />
          </span>
        </div>

        {/* ---------------- SECTIONS ---------------- */}
        {data.sections.map((section, i) => (
          <SectionShell
            key={section.id}
            section={section}
            editMode={editMode}
            canUp={i > 0}
            canDown={i < data.sections.length - 1}
            onTitleChange={(v) => patchSection(section.id, { title: v })}
            onMoveUp={() => moveSection(section.id, -1)}
            onMoveDown={() => moveSection(section.id, 1)}
            onRemove={() => removeSection(section.id)}
          >
            {section.type === "cards" && (
              <div className="knt-grid">
                {section.items.map((item) => (
                  <article key={item.id} className="knt-card">
                    {editMode && (
                      <button
                        className="knt-card-remove"
                        onClick={() => patchItems(section.id, (items) => items.filter((it) => it.id !== item.id))}
                      >
                        <Trash2 size={13} strokeWidth={2} />
                      </button>
                    )}
                    <ImageBox
                      value={item.image}
                      editMode={editMode}
                      className="knt-card-media"
                      Icon={Cpu}
                      onChange={(v) =>
                        patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, image: v } : it)))
                      }
                    />
                    <div className="knt-card-body">
                      <EditableText
                        className="knt-card-tag"
                        value={item.tag}
                        placeholder="Categoria"
                        editMode={editMode}
                        onChange={(v) => patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, tag: v } : it)))}
                      />
                      <EditableText
                        tag="h3"
                        className="knt-card-title"
                        value={item.title}
                        placeholder="Nome do item"
                        editMode={editMode}
                        onChange={(v) => patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, title: v } : it)))}
                      />
                      <EditableText
                        className="knt-card-detail"
                        value={item.detail}
                        placeholder="Detalhe / especificação"
                        editMode={editMode}
                        onChange={(v) => patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, detail: v } : it)))}
                      />
                    </div>
                  </article>
                ))}
                {editMode && (
                  <button
                    className="knt-add-card"
                    onClick={() =>
                      patchItems(section.id, (items) => [...items, { id: uid(), image: "", tag: "", title: "Novo item", detail: "" }])
                    }
                  >
                    <Plus size={18} strokeWidth={1.8} />
                    <span>Adicionar item</span>
                  </button>
                )}
                {!editMode && section.items.length === 0 && <p className="knt-empty">Nada por aqui ainda.</p>}
              </div>
            )}

            {section.type === "blocks" && (
              <div className="knt-blocks">
                {section.items.map((item) => (
                  <article key={item.id} className="knt-block">
                    {editMode && (
                      <button
                        className="knt-card-remove"
                        onClick={() => patchItems(section.id, (items) => items.filter((it) => it.id !== item.id))}
                      >
                        <Trash2 size={13} strokeWidth={2} />
                      </button>
                    )}
                    <ImageBox
                      value={item.image}
                      editMode={editMode}
                      className="knt-block-media"
                      onChange={(v) =>
                        patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, image: v } : it)))
                      }
                    />
                    <div className="knt-block-body">
                      <EditableText
                        tag="h3"
                        className="knt-block-title"
                        value={item.title}
                        placeholder="Título do bloco"
                        editMode={editMode}
                        onChange={(v) => patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, title: v } : it)))}
                      />
                      <EditableArea
                        className="knt-block-content"
                        value={item.content}
                        placeholder="Escreva algo…"
                        editMode={editMode}
                        onChange={(v) => patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, content: v } : it)))}
                      />
                    </div>
                  </article>
                ))}
                {editMode && (
                  <button
                    className="knt-add-card knt-add-card--wide"
                    onClick={() => patchItems(section.id, (items) => [...items, { id: uid(), image: "", title: "Novo bloco", content: "" }])}
                  >
                    <Plus size={18} strokeWidth={1.8} />
                    <span>Adicionar bloco</span>
                  </button>
                )}
                {!editMode && section.items.length === 0 && <p className="knt-empty">Nada por aqui ainda.</p>}
              </div>
            )}

            {section.type === "links" && (
              <div className="knt-links">
                {section.items.map((item) => {
                  const Icon = platformIcon(item.platform);
                  if (!editMode) {
                    return (
                      <a key={item.id} href={item.url || "#"} target="_blank" rel="noreferrer" className="knt-social-pill">
                        <Icon size={15} strokeWidth={1.8} />
                        <span>{item.label || item.url}</span>
                      </a>
                    );
                  }
                  return (
                    <div key={item.id} className="knt-link-edit-row">
                      <select
                        className="knt-select"
                        value={item.platform}
                        onChange={(e) =>
                          patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, platform: e.target.value } : it)))
                        }
                      >
                        {PLATFORMS.map((p) => (
                          <option key={p.id} value={p.id}>{p.label}</option>
                        ))}
                      </select>
                      <input
                        className="knt-mini-input"
                        placeholder="Rótulo (ex: twitch.tv/voce)"
                        value={item.label}
                        onChange={(e) =>
                          patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, label: e.target.value } : it)))
                        }
                      />
                      <input
                        className="knt-mini-input"
                        placeholder="https://…"
                        value={item.url}
                        onChange={(e) =>
                          patchItems(section.id, (items) => items.map((it) => (it.id === item.id ? { ...it, url: e.target.value } : it)))
                        }
                      />
                      <button
                        className="knt-row-remove"
                        onClick={() => patchItems(section.id, (items) => items.filter((it) => it.id !== item.id))}
                      >
                        <X size={14} strokeWidth={2} />
                      </button>
                    </div>
                  );
                })}
                {editMode && (
                  <button
                    className="knt-add-row knt-add-row--boxed"
                    onClick={() =>
                      patchItems(section.id, (items) => [...items, { id: uid(), platform: "website", label: "", url: "" }])
                    }
                  >
                    <Plus size={14} strokeWidth={2} /> Adicionar link
                  </button>
                )}
                {!editMode && section.items.length === 0 && <p className="knt-empty">Nenhum link ainda.</p>}
              </div>
            )}

            {section.type === "settings" && (
              <div className="knt-settings">
                <div className="knt-game-picker">
                  {section.games.map((g) => (
                    <div key={g.id} className="knt-pill-wrap">
                      <button
                        className={`knt-pill ${section.activeGameId === g.id ? "knt-pill--active" : ""}`}
                        onClick={() => patchSection(section.id, { activeGameId: g.id })}
                      >
                        {editMode ? (
                          <input
                            className="knt-pill-input"
                            value={g.name}
                            placeholder="Jogo"
                            onChange={(e) => updateGameInSettings(section.id, g.id, "name", e.target.value)}
                            onClick={(e) => e.stopPropagation()}
                          />
                        ) : (
                          g.name
                        )}
                      </button>
                      {editMode && (
                        <button className="knt-pill-remove" onClick={() => removeGameFromSettings(section.id, g.id)}>
                          <X size={11} strokeWidth={2.2} />
                        </button>
                      )}
                    </div>
                  ))}
                  {editMode && (
                    <button className="knt-pill knt-pill--add" onClick={() => addGameToSettings(section.id)}>
                      <Plus size={13} strokeWidth={2} /> Jogo
                    </button>
                  )}
                </div>

                {section.games.length === 0 && <p className="knt-empty">Adicione um jogo para registrar as configurações.</p>}

                {section.activeGameId && (
                  <div className="knt-settings-table">
                    {(section.settingsByGame[section.activeGameId] || []).map((row) => (
                      <div key={row.id} className="knt-settings-row">
                        <EditableText
                          className="knt-settings-label"
                          value={row.label}
                          placeholder="Configuração"
                          editMode={editMode}
                          onChange={(v) => updateSettingRow(section.id, section.activeGameId, row.id, "label", v)}
                        />
                        <EditableText
                          className="knt-settings-value"
                          value={row.value}
                          placeholder="Valor"
                          editMode={editMode}
                          onChange={(v) => updateSettingRow(section.id, section.activeGameId, row.id, "value", v)}
                        />
                        {editMode && (
                          <button className="knt-row-remove" onClick={() => removeSettingRow(section.id, section.activeGameId, row.id)}>
                            <X size={14} strokeWidth={2} />
                          </button>
                        )}
                      </div>
                    ))}
                    {(section.settingsByGame[section.activeGameId] || []).length === 0 && !editMode && (
                      <p className="knt-empty">Nenhuma configuração registrada.</p>
                    )}
                    {editMode && (
                      <button className="knt-add-row" onClick={() => addSettingRow(section.id, section.activeGameId)}>
                        <Plus size={14} strokeWidth={2} /> Adicionar configuração
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </SectionShell>
        ))}

        {/* ---------------- ADD SECTION ---------------- */}
        {editMode && (
          <div className="knt-add-section">
            {!pickerOpen ? (
              <button className="knt-add-section-btn" onClick={() => setPickerOpen(true)}>
                <Plus size={16} strokeWidth={2} /> Adicionar seção
              </button>
            ) : (
              <div className="knt-picker">
                {SECTION_TYPES.map((t) => (
                  <button key={t.type} className="knt-picker-option" onClick={() => addSection(t.type)}>
                    <t.icon size={18} strokeWidth={1.7} />
                    <span className="knt-picker-label">{t.label}</span>
                    <span className="knt-picker-hint">{t.hint}</span>
                  </button>
                ))}
                <button className="knt-picker-cancel" onClick={() => setPickerOpen(false)}>
                  <X size={14} strokeWidth={2} />
                </button>
              </div>
            )}
          </div>
        )}

        <footer className="knt-footer">
          <LinkIcon size={12} strokeWidth={2} />
          <span>seusite.gg/{data.profile.handle || "usuario"}</span>
        </footer>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------
   CSS — design tokens live here
--------------------------------------------------------- */
const CSS = `
:root{
  --bg:#121210;
  --surface:#191814;
  --surface-2:#211f1a;
  --border:#322f27;
  --border-soft:#26241f;
  --text:#f3f1ea;
  --text-dim:#a39d8e;
  --text-faint:#736c5d;
  --accent:#c9ff3d;
  --accent-ink:#141604;
  --radius:14px;
  --font-display:'Space Grotesk', 'Inter', sans-serif;
  --font-body:'Inter', sans-serif;
}
.knt-root{ background:var(--bg); color:var(--text); font-family:var(--font-body); min-height:100%; width:100%; -webkit-font-smoothing:antialiased; }
.knt-placeholder{ color:var(--text-faint); }

.knt-banner{ height:150px; width:100%; position:relative; }
.knt-banner-img{ position:absolute; inset:0; border-radius:0; }

.knt-shell{ max-width:840px; margin:0 auto; padding:0 24px 64px; }

.knt-header{ display:flex; gap:22px; margin-top:-46px; position:relative; }
.knt-avatar{ width:92px; height:92px; border:3px solid var(--bg); flex-shrink:0; }
.knt-id{ flex:1; padding-top:52px; min-width:0; }
.knt-id-row{ display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; }
.knt-name{ font-family:var(--font-display); font-weight:600; font-size:26px; letter-spacing:-0.01em; margin:0; }
.knt-editbtn{ display:flex; align-items:center; gap:6px; background:var(--surface-2); border:1px solid var(--border); color:var(--text); font-size:12.5px; font-weight:500; padding:7px 13px; border-radius:999px; cursor:pointer; transition:background .15s ease, border-color .15s ease; }
.knt-editbtn:hover{ border-color:#4a4536; }
.knt-editbtn--active{ background:var(--accent); color:var(--accent-ink); border-color:var(--accent); }
.knt-handle-row{ display:flex; align-items:center; gap:5px; margin-top:4px; color:var(--text-dim); font-size:13.5px; flex-wrap:wrap; }
.knt-handle-at{ color:var(--text-faint); }
.knt-dot{ color:var(--text-faint); margin:0 2px; }
.knt-loc-icon{ color:var(--text-faint); margin-left:2px; }
.knt-bio{ margin:12px 0 0; color:var(--text-dim); font-size:14.5px; line-height:1.55; max-width:60ch; }

.knt-save-status{ display:flex; align-items:center; gap:5px; font-size:11px; color:var(--text-faint); margin-top:18px; height:auto; flex-wrap:wrap; }
.knt-backup-row{ display:flex; gap:6px; margin-left:auto; }
.knt-backup-btn{ display:flex; align-items:center; gap:4px; background:none; border:1px solid var(--border-soft); color:var(--text-faint); font-size:11px; padding:5px 9px; border-radius:7px; cursor:pointer; }
.knt-backup-btn:hover{ color:var(--text); border-color:#4a4536; }
.knt-spin{ animation:knt-spin .9s linear infinite; }
@keyframes knt-spin{ to{ transform:rotate(360deg); } }

.knt-inline-input, .knt-inline-textarea, .knt-mini-input, .knt-select{
  background:var(--surface-2); border:1px solid var(--border); color:var(--text);
  border-radius:8px; font-family:inherit; padding:5px 8px; font-size:inherit; width:100%; outline:none;
}
.knt-inline-input:focus, .knt-inline-textarea:focus, .knt-mini-input:focus, .knt-select:focus{ border-color:var(--accent); }
.knt-inline-textarea{ resize:vertical; }
.knt-mini-input{ font-size:12px; background:transparent; border:1px dashed var(--border); }
.knt-name .knt-inline-input{ font-family:var(--font-display); font-size:22px; font-weight:600; }
.knt-select{ font-size:12px; }

/* image upload box */
.knt-imgbox{
  position:relative; background:var(--surface-2); background-size:cover; background-position:center;
  display:flex; align-items:center; justify-content:center; color:var(--text-faint);
  border-radius:11px; outline:1px solid var(--border);
}
.knt-imgbox--round{ border-radius:22px; outline:1px solid var(--border); }
.knt-imgbox-overlay{ position:absolute; inset:0; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; background:rgba(8,8,6,0.38); border-radius:inherit; opacity:0; transition:opacity .15s ease; }
.knt-imgbox:hover .knt-imgbox-overlay, .knt-imgbox:focus-within .knt-imgbox-overlay{ opacity:1; }
.knt-imgbox-controls{ display:flex; gap:5px; }
.knt-imgbox-btn{ display:flex; align-items:center; gap:4px; background:rgba(15,15,12,0.85); border:1px solid var(--border); color:var(--text); font-size:11px; padding:5px 8px; border-radius:7px; cursor:pointer; }
.knt-imgbox-btn:hover{ border-color:var(--accent); }
.knt-imgbox-btn--danger:hover{ border-color:#ff6a5a; color:#ff6a5a; }
.knt-imgbox-urlinput{ width:85%; font-size:11px; }

.knt-section{ margin-top:38px; }
.knt-section-head{ display:flex; align-items:center; justify-content:space-between; gap:10px; border-bottom:1px solid var(--border-soft); padding-bottom:10px; margin-bottom:16px; }
.knt-section-title{ font-family:var(--font-display); font-size:15.5px; font-weight:600; margin:0; color:var(--text); }
.knt-section-title.knt-inline-input{ font-family:var(--font-display); font-size:15px; font-weight:600; max-width:260px; }
.knt-section-controls{ display:flex; gap:5px; flex-shrink:0; }
.knt-iconbtn{ width:26px; height:26px; display:flex; align-items:center; justify-content:center; background:var(--surface); border:1px solid var(--border-soft); color:var(--text-dim); border-radius:7px; cursor:pointer; }
.knt-iconbtn:hover{ color:var(--text); border-color:#4a4536; }
.knt-iconbtn:disabled{ opacity:.3; cursor:default; }
.knt-iconbtn--danger:hover{ color:#ff6a5a; border-color:#ff6a5a; }

.knt-grid{ display:grid; grid-template-columns:repeat(auto-fill, minmax(190px,1fr)); gap:14px; }
.knt-card{ background:var(--surface); border:1px solid var(--border-soft); border-radius:var(--radius); padding:12px; position:relative; display:flex; flex-direction:column; gap:10px; }
.knt-card-remove{ position:absolute; top:10px; right:10px; z-index:2; width:24px; height:24px; background:rgba(10,10,8,0.7); border:1px solid var(--border); color:var(--text-dim); border-radius:7px; display:flex; align-items:center; justify-content:center; cursor:pointer; }
.knt-card-remove:hover{ color:#ff6a5a; border-color:#ff6a5a; }
.knt-card-media{ height:110px; }
.knt-card-body{ display:flex; flex-direction:column; gap:3px; }
.knt-card-tag{ font-size:10.5px; color:var(--accent); font-weight:600; }
.knt-card-title{ font-family:var(--font-display); font-size:15px; font-weight:600; margin:0; }
.knt-card-detail{ font-size:12.5px; color:var(--text-dim); line-height:1.4; }

.knt-add-card{ border:1.5px dashed var(--border); border-radius:var(--radius); background:none; color:var(--text-faint); min-height:150px; display:flex; flex-direction:column; align-items:center; justify-content:center; gap:6px; cursor:pointer; font-size:13px; transition:border-color .15s ease, color .15s ease; }
.knt-add-card:hover{ border-color:var(--accent); color:var(--accent); }
.knt-add-card--wide{ min-height:100px; }

.knt-blocks{ display:grid; grid-template-columns:repeat(auto-fill, minmax(260px,1fr)); gap:14px; }
.knt-block{ background:var(--surface); border:1px solid var(--border-soft); border-radius:var(--radius); overflow:hidden; position:relative; display:flex; flex-direction:column; }
.knt-block-media{ height:140px; border-radius:0; }
.knt-block-body{ padding:14px; display:flex; flex-direction:column; gap:6px; }
.knt-block-title{ font-family:var(--font-display); font-size:16px; font-weight:600; margin:0; }
.knt-block-content{ font-size:13px; color:var(--text-dim); line-height:1.55; margin:0; }

.knt-links{ display:flex; flex-direction:column; gap:8px; }
.knt-social-pill{ display:flex; align-items:center; gap:8px; background:var(--surface); border:1px solid var(--border-soft); color:var(--text-dim); font-size:13px; padding:9px 13px; border-radius:10px; text-decoration:none; width:fit-content; transition:color .15s ease, border-color .15s ease; }
.knt-social-pill:hover{ color:var(--text); border-color:#4a4536; }
.knt-link-edit-row{ display:flex; align-items:center; gap:8px; background:var(--surface); border:1px solid var(--border-soft); padding:8px; border-radius:10px; }
.knt-link-edit-row .knt-select{ max-width:130px; flex-shrink:0; }
.knt-link-edit-row .knt-mini-input{ flex:1; }

.knt-settings{ display:flex; flex-direction:column; gap:16px; }
.knt-game-picker{ display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
.knt-pill-wrap{ position:relative; }
.knt-pill{ background:var(--surface); border:1px solid var(--border-soft); color:var(--text-dim); padding:7px 14px; border-radius:999px; font-size:13px; cursor:pointer; display:flex; align-items:center; gap:5px; }
.knt-pill--active{ background:var(--accent); color:var(--accent-ink); border-color:var(--accent); font-weight:600; }
.knt-pill--add{ border-style:dashed; }
.knt-pill-input{ background:none; border:none; color:inherit; font-size:13px; width:90px; outline:none; }
.knt-pill-remove{ position:absolute; top:-6px; right:-6px; width:16px; height:16px; border-radius:50%; background:var(--surface); border:1px solid var(--border); color:var(--text-faint); display:flex; align-items:center; justify-content:center; cursor:pointer; }
.knt-pill-remove:hover{ color:#ff6a5a; border-color:#ff6a5a; }
.knt-settings-table{ background:var(--surface); border:1px solid var(--border-soft); border-radius:var(--radius); overflow:hidden; }
.knt-settings-row{ display:flex; align-items:center; gap:12px; padding:12px 16px; border-bottom:1px solid var(--border-soft); }
.knt-settings-row:last-child{ border-bottom:none; }
.knt-settings-label{ width:150px; flex-shrink:0; color:var(--text-dim); font-size:13px; }
.knt-settings-value{ flex:1; font-size:13.5px; font-weight:500; font-family:'Space Grotesk', monospace; }
.knt-row-remove{ background:none; border:none; color:var(--text-faint); cursor:pointer; flex-shrink:0; }
.knt-row-remove:hover{ color:#ff6a5a; }
.knt-add-row{ display:flex; align-items:center; gap:6px; background:none; border:none; color:var(--text-faint); font-size:12.5px; padding:12px 16px; cursor:pointer; width:100%; justify-content:flex-start; }
.knt-add-row:hover{ color:var(--accent); }
.knt-add-row--boxed{ border:1.5px dashed var(--border); border-radius:10px; padding:10px 14px; width:fit-content; }
.knt-add-row--boxed:hover{ border-color:var(--accent); }
.knt-empty{ color:var(--text-faint); font-size:13px; }

.knt-add-section{ margin-top:38px; }
.knt-add-section-btn{ display:flex; align-items:center; gap:7px; background:none; border:1.5px dashed var(--border); color:var(--text-faint); font-size:13.5px; padding:12px 18px; border-radius:12px; cursor:pointer; width:100%; justify-content:center; }
.knt-add-section-btn:hover{ border-color:var(--accent); color:var(--accent); }
.knt-picker{ position:relative; display:grid; grid-template-columns:repeat(auto-fit, minmax(150px,1fr)); gap:10px; background:var(--surface); border:1px solid var(--border-soft); border-radius:14px; padding:16px; }
.knt-picker-option{ display:flex; flex-direction:column; align-items:flex-start; gap:6px; background:var(--surface-2); border:1px solid var(--border-soft); color:var(--text); padding:14px; border-radius:11px; cursor:pointer; text-align:left; }
.knt-picker-option:hover{ border-color:var(--accent); }
.knt-picker-label{ font-size:13px; font-weight:600; }
.knt-picker-hint{ font-size:11px; color:var(--text-faint); }
.knt-picker-cancel{ position:absolute; top:10px; right:10px; width:24px; height:24px; display:flex; align-items:center; justify-content:center; background:var(--surface-2); border:1px solid var(--border-soft); color:var(--text-dim); border-radius:7px; cursor:pointer; }

.knt-footer{ display:flex; align-items:center; gap:6px; justify-content:center; margin-top:56px; color:var(--text-faint); font-size:11.5px; }

@media (max-width:560px){
  .knt-header{ flex-direction:column; }
  .knt-id{ padding-top:12px; }
  .knt-settings-label{ width:110px; }
  .knt-link-edit-row{ flex-wrap:wrap; }
}
`;
