# Perfil Gamer — Cloudflare Pages

Site de página única para mostrar setup, jogos favoritos, configurações e links, com seções que você pode adicionar/remover.

## O que mudou em relação ao artifact do Claude

- **Armazenamento:** trocamos `window.storage` (só existe dentro do Claude) por `localStorage` do navegador. Os dados salvam automaticamente, mas ficam **só no navegador de quem está vendo a página** — não sincronizam entre dispositivos e não aparecem iguais para outras pessoas que visitarem o link. Para um perfil público editável só por você e visível igual para todo mundo, você precisaria de um backend real. Como já está no Cloudflare, o caminho mais natural seria **Cloudflare D1** (banco SQL) ou **KV** acessado via **Pages Functions** — posso montar isso se quiser evoluir pra essa versão.
- **Imagens:** upload continua funcionando (compressão no navegador, salva como base64 dentro do JSON do localStorage). Evite dezenas de fotos em alta resolução — o limite prático de localStorage é uns 5-10MB por site.

## Rodar localmente

```bash
npm install
npm run dev
```

Abre em `http://localhost:5173`.

## Publicar no Cloudflare Pages

### Opção A — pelo painel (mais simples, deploy automático a cada push)

1. Suba este projeto para um repositório no GitHub (ou GitLab):
   ```bash
   git init
   git add .
   git commit -m "primeiro commit"
   git branch -M main
   git remote add origin https://github.com/SEU-USUARIO/NOME-DO-REPOSITORIO.git
   git push -u origin main
   ```
2. No [dashboard da Cloudflare](https://dash.cloudflare.com/) → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
3. Selecione o repositório e configure o build:
   - **Framework preset:** Vite
   - **Build command:** `npm run build`
   - **Build output directory:** `dist`
4. Clique em **Save and Deploy**. O site fica em `https://NOME-DO-PROJETO.pages.dev`.
5. Qualquer novo `git push` na branch principal dispara um novo deploy automaticamente.

### Opção B — pela CLI (`wrangler`), sem precisar de Git

```bash
npm install
npm run build
npx wrangler login      # abre o navegador para autenticar com sua conta Cloudflare
npm run deploy          # builda de novo e publica via wrangler pages deploy
```

Na primeira vez, o `wrangler` pergunta o nome do projeto Pages a criar — pode aceitar o padrão (`gamer-profile-site`, já definido em `wrangler.toml`).

## Domínio próprio

Depois de publicado, em **Workers & Pages → seu projeto → Custom domains** dá pra apontar um domínio próprio (ex: `seunome.gg`) direto pelo painel.
